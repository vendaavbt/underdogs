import { Controller } from '@nestjs/common';

@Controller('authors')
export class AuthorController {}
