import { Controller } from '@nestjs/common';

@Controller('genres')
export class GenreController {}
