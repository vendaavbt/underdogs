'use client';

import { FC } from 'react';

const AuthorsPage: FC = () => <>Authors page not implemented</>;

export default AuthorsPage;
