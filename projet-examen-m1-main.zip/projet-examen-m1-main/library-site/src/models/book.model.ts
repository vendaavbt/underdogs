export type PlainBookModel = {
  id: string;
  name: string;
};
